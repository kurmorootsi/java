/**
 * Created by Kurmo on 8.12.2016.
 */
public class banaan {
    protected double Kaal;
    protected int Küpsustase;
    protected String Sort;
    protected double Baashind;

}
