/**
 * Created by Kurmo on 1.11.2016.
 */
public class homework2 {
    public static void main(String[] args){
        SuperKangelane Marco = new SuperKangelane();
        Marco.setNimi("Marco");
        Marco.setAsukoht("Mustika Küla");
        Marco.setOsavus();
        Marco.päästa(120);
        Marco.getNimi();
        Marco.getAsukoht();

    }
}
